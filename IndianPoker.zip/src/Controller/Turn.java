package Controller;

public class Turn {
	int turn;
	
	public Turn(){
		turn = 0;
	}
	
	public void setTurn(int turn){
		this.turn = turn;
	}
	
	public int getTurn(){
		return turn;
	}

}
